import random
from collections import defaultdict

def player(prev_play, opponent_history=[], my_history=[]):
    if prev_play:
        opponent_history.append(prev_play)
    else:
        # Reset history at start of new match
        opponent_history.clear()
        my_history.clear()

    # Default first move
    if not opponent_history:
        my_history.append("P")
        return "P"

    # Counter Quincy's pattern (RRPPS)
    quincy_pattern = ["R", "R", "P", "P", "S"]
    if len(opponent_history) >= 5:
        last_five = opponent_history[-5:]
        if last_five == quincy_pattern:
            counter = ["P", "P", "S", "S", "R"][len(opponent_history) % 5]
            my_history.append(counter)
            return counter

    # Counter Abbey's Markov strategy (Use 3-Move Prediction)
    if len(opponent_history) >= 5:
        last_three = "".join(opponent_history[-3:])
        possibilities = [last_three + "R", last_three + "P", last_three + "S"]
        
        # Build frequency table of move sequences
        freq = defaultdict(int)
        for i in range(len(opponent_history)-3):
            sequence = "".join(opponent_history[i:i+3])
            next_move = opponent_history[i+3]
            freq[sequence + next_move] += 1

        # Predict Abbey's next move
        predicted = max(possibilities, key=lambda x: freq.get(x, 0))[-1]
        counter = {"R": "P", "P": "S", "S": "R"}[predicted]
        my_history.append(counter)
        return counter

    # Counter Kris (who always counters your last move)
    if len(my_history) > 1:
        # Predict Kris's counter move
        kris_move = {"R": "P", "P": "S", "S": "R"}[my_history[-1]]
        counter = {"R": "P", "P": "S", "S": "R"}[kris_move]  # Counter his counter
        my_history.append(counter)
        return counter

    # Counter Mrugesh (most frequent move in last 15 rounds)
    if len(opponent_history) >= 15:
        counts = {"R": 0, "P": 0, "S": 0}
        for move in opponent_history[-15:]:
            counts[move] += 1
        most_frequent = max(counts, key=counts.get)
        counter = {"R": "P", "P": "S", "S": "R"}[most_frequent]
        my_history.append(counter)
        return counter

    # Fallback: Unpredictable rotating pattern
    moves = ["P", "S", "R", "P", "S", "R"]
    move = moves[len(opponent_history) % len(moves)]
    my_history.append(move)
    return move
